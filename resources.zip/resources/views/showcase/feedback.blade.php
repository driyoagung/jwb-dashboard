<x-layouts.admin title="Umpan balik" group="Komponen">
<x-ui.page-header title="Umpan balik" description="Alert, toast, modal, drawer, progres, spinner, dan skeleton." />

<x-ui.card title="Alert" description="Empat nada semantik, dengan judul, tombol tutup, dan aksi.">
  <div class="space-y-3">
    <div class="alert alert-info" role="alert"><x-ui.icon name="info" class="alert-icon mt-0.5 h-4 w-4 shrink-0" /><div><p class="alert-title">Pembaruan tersedia</p><p class="text-muted-foreground">Versi baru dashboard siap dipasang.</p></div></div>
    <div class="alert alert-success" role="alert"><x-ui.icon name="check-circle" class="alert-icon mt-0.5 h-4 w-4 shrink-0" /><div><p class="alert-title">Pesanan berhasil disimpan</p><p class="text-muted-foreground">Pelanggan sudah menerima email konfirmasi.</p></div></div>
    <div class="alert alert-warning" role="alert"><x-ui.icon name="alert-triangle" class="alert-icon mt-0.5 h-4 w-4 shrink-0" /><div><p class="alert-title">Stok menipis</p><p class="text-muted-foreground">Toraja Sapan 500 g tersisa 18 unit.</p></div></div>
    <div class="alert alert-danger" role="alert"><x-ui.icon name="alert-circle" class="alert-icon mt-0.5 h-4 w-4 shrink-0" /><div><p class="alert-title">Pembayaran gagal</p><p class="text-muted-foreground">Periksa kembali metode pembayaran Anda.</p></div></div>
    <div class="alert alert-info items-center" data-dismissible role="status"><x-ui.icon name="info" class="alert-icon h-4 w-4 shrink-0" /><p class="flex-1">Alert dengan tombol tutup dan aksi.</p><a href="#" class="btn btn-link">Lihat</a><button type="button" data-dismiss class="rounded p-1 text-muted-foreground hover:text-foreground" aria-label="Tutup"><x-ui.icon name="x" /></button></div>
    <div class="alert alert-solid items-center" role="status"><x-ui.icon name="zap" class="h-4 w-4 shrink-0" /><p>Alert solid: sorotan berkontras tinggi untuk pengumuman.</p></div>
  </div>
</x-ui.card>

<section class="grid gap-4 lg:grid-cols-2">
  <x-ui.card title="Toast" description="Notifikasi singkat lewat App.toast(). Klik untuk mencoba.">
    <div class="flex flex-wrap gap-3">
      <button type="button" class="btn btn-outline" data-toast="success" data-toast-title="Berhasil disimpan" data-toast-desc="Perubahan Anda sudah tersimpan.">Success</button>
      <button type="button" class="btn btn-outline" data-toast="danger" data-toast-title="Terjadi kesalahan" data-toast-desc="Coba lagi beberapa saat lagi.">Danger</button>
      <button type="button" class="btn btn-outline" data-toast="warning" data-toast-title="Perhatian" data-toast-desc="Sesi Anda akan berakhir dalam 5 menit.">Warning</button>
      <button type="button" class="btn btn-outline" data-toast="info" data-toast-title="Informasi" data-toast-desc="Ada 3 pesanan baru.">Info</button>
      <button type="button" class="btn btn-outline" data-toast="neutral" data-toast-title="Toast sederhana">Netral</button>
    </div>
  </x-ui.card>

  <x-ui.card title="Modal dan drawer" description="Memakai elemen dialog bawaan browser (fokus dan Esc otomatis).">
    <div class="flex flex-wrap gap-3">
      <button type="button" class="btn btn-primary" data-modal-open="#modal-form">Modal formulir</button>
      <button type="button" class="btn btn-outline" data-modal-open="#modal-info">Modal info</button>
      <button type="button" class="btn btn-destructive" data-modal-open="#modal-confirm">Konfirmasi hapus</button>
      <button type="button" class="btn btn-outline" data-modal-open="#drawer-filter"><x-ui.icon name="filter" />Drawer filter</button>
    </div>
  </x-ui.card>

  <x-ui.card title="Progres" description="Bilah progres berbagai nada dan ukuran.">
    <div class="space-y-4">
      <div><div class="mb-1.5 flex justify-between text-sm"><span>Unggahan</span><span class="text-muted-foreground">68%</span></div><div class="progress"><div class="progress-bar" style="width:68%"></div></div></div>
      <div><div class="mb-1.5 flex justify-between text-sm"><span>Stok aman</span><span class="text-muted-foreground">86%</span></div><div class="progress"><div class="progress-bar bg-positive" style="width:86%"></div></div></div>
      <div><div class="mb-1.5 flex justify-between text-sm"><span>Kuota penyimpanan</span><span class="text-muted-foreground">54%</span></div><div class="progress"><div class="progress-bar bg-caution" style="width:54%"></div></div></div>
      <div><div class="mb-1.5 flex justify-between text-sm"><span>Batas API</span><span class="text-muted-foreground">93%</span></div><div class="progress h-3"><div class="progress-bar bg-destructive" style="width:93%"></div></div></div>
      <div class="progress h-1"><div class="progress-bar" style="width:40%"></div></div>
    </div>
  </x-ui.card>

  <x-ui.card title="Spinner" description="Indikator pemuatan.">
    <div class="flex flex-wrap items-center gap-6">
      <span class="spinner text-primary"></span>
      <span class="spinner h-6 w-6 text-primary"></span>
      <span class="spinner h-8 w-8 border-[3px] text-info"></span>
      <span class="spinner h-8 w-8 border-[3px] text-success"></span>
      <span class="inline-flex items-center gap-2 text-muted-foreground"><span class="spinner"></span>Memuat data</span>
    </div>
  </x-ui.card>
</section>

<x-ui.card title="Skeleton" description="Placeholder saat konten dimuat.">
  <div class="grid gap-6 md:grid-cols-2">
    <div class="flex items-center gap-4">
      <div class="skeleton h-12 w-12 rounded-full"></div>
      <div class="flex-1 space-y-2"><div class="skeleton h-4 w-2/3"></div><div class="skeleton h-4 w-1/2"></div></div>
    </div>
    <div class="space-y-3"><div class="skeleton h-32 w-full"></div><div class="skeleton h-4 w-full"></div><div class="skeleton h-4 w-4/5"></div></div>
  </div>
</x-ui.card>

<x-ui.modal id="modal-form" title="Tambah produk" description="Isi detail produk baru untuk katalog Anda.">
    <div class="space-y-4">
      <div class="space-y-2"><label class="label" for="mf-name">Nama produk</label><input id="mf-name" class="input" placeholder="Contoh: Arabika Gayo 1 kg"></div>
      <div class="grid grid-cols-2 gap-3">
        <div class="space-y-2"><label class="label" for="mf-price">Harga</label><div class="input-group"><span class="input-addon">Rp</span><input id="mf-price" class="input" placeholder="170000"></div></div>
        <div class="space-y-2"><label class="label" for="mf-stock">Stok</label><input id="mf-stock" type="number" class="input" placeholder="0"></div>
      </div>
    </div>
    <x-slot:footer><button type="button" class="btn btn-outline" data-modal-close>Batal</button><button type="button" class="btn btn-primary" data-modal-close data-toast="success" data-toast-title="Produk ditambahkan">Simpan</button></x-slot:footer>
</x-ui.modal>

<x-ui.modal id="modal-info" title="Pembaruan dijadwalkan" description="Sistem akan menjalani pemeliharaan Minggu pukul 01.00–03.00 WIB. Dashboard tetap bisa dibuka." icon="info" tone="info" size="sm">
    <x-slot:footer><button type="button" class="btn btn-primary" data-modal-close>Mengerti</button></x-slot:footer>
</x-ui.modal>

<x-ui.modal id="modal-confirm" title="Hapus pesanan?" description="Pesanan #KK-2837 akan dihapus permanen dan tidak bisa dipulihkan." icon="trash" tone="danger" size="sm">
    <x-slot:footer><button type="button" class="btn btn-outline" data-modal-close>Batal</button><button type="button" class="btn btn-destructive" data-modal-close data-toast="danger" data-toast-title="Pesanan dihapus">Ya, hapus</button></x-slot:footer>
</x-ui.modal>

<x-ui.drawer id="drawer-filter" title="Filter pesanan">
    <div class="space-y-5">
      <div class="space-y-2"><label class="label" for="df-status">Status</label><select id="df-status" class="select"><option>Semua</option><option>Selesai</option><option>Dikirim</option><option>Diproses</option></select></div>
      <div class="space-y-2"><span class="label">Rentang tanggal</span><div class="grid grid-cols-2 gap-2"><input type="date" class="input" aria-label="Dari"><input type="date" class="input" aria-label="Sampai"></div></div>
      <div class="space-y-3"><span class="label">Kanal</span>
        <label class="flex items-center gap-2"><input type="checkbox" checked> Situs web</label>
        <label class="flex items-center gap-2"><input type="checkbox" checked> Marketplace</label>
        <label class="flex items-center gap-2"><input type="checkbox"> WhatsApp</label>
      </div>
    </div>
    <x-slot:footer><button type="button" class="btn btn-outline flex-1" data-modal-close>Atur ulang</button><button type="button" class="btn btn-primary flex-1" data-modal-close>Terapkan</button></x-slot:footer>
</x-ui.drawer>
</x-layouts.admin>
